import { SignUp } from '@clerk/nextjs';


const Page = () => {
    return <SignUp />;
};

export default Page;

